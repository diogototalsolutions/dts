import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Lock, Mail, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';

const LoginPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { login, resetPassword } = useAuth();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [isResettingPassword, setIsResettingPassword] = useState(false);
  const [resetEmail, setResetEmail] = useState('');

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const success = login(formData.email, formData.password);
    
    if (success) {
      toast({
        title: "Login Realizado! ✓",
        description: "Bem-vindo ao painel administrativo.",
        duration: 3000,
      });
      navigate('/admin/dashboard');
    } else {
      toast({
        title: "Erro de Autenticação",
        description: "Email ou senha incorretos. Tente novamente.",
        variant: "destructive",
        duration: 5000,
      });
    }
  };

  const handlePasswordReset = async (e) => {
    e.preventDefault();
    
    await resetPassword(resetEmail);
    
    toast({
      title: "Email Enviado! ✓",
      description: "Verifique sua caixa de entrada para redefinir sua senha.",
      duration: 5000,
    });
    
    setIsResettingPassword(false);
    setResetEmail('');
  };

  return (
    <>
      <Helmet>
        <title>Login - Diogo Tech Solutions</title>
        <meta name="description" content="Área de login para funcionários da Diogo Tech Solutions. Acesse o painel administrativo." />
      </Helmet>

      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-600 via-blue-700 to-blue-900 px-6 py-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="w-full max-w-md"
        >
          <div className="bg-white rounded-2xl shadow-2xl p-8">
            <div className="text-center mb-8">
              <img 
                src="https://horizons-cdn.hostinger.com/c7ead2cc-c9d2-4819-948e-421c71680a94/a697d1962d9c248c045374b150919108.jpg" 
                alt="Diogo Tech Solutions" 
                className="h-16 w-auto object-contain mx-auto mb-4"
              />
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {isResettingPassword ? 'Redefinir Senha' : 'Login de Funcionário'}
              </h1>
              <p className="text-gray-600">
                {isResettingPassword 
                  ? 'Informe seu email para recuperar o acesso'
                  : 'Acesse o painel administrativo'
                }
              </p>
            </div>

            {!isResettingPassword ? (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Email
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all bg-white text-gray-900 placeholder-gray-400"
                      placeholder="seu@email.com"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                    Senha
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="password"
                      id="password"
                      name="password"
                      value={formData.password}
                      onChange={handleChange}
                      required
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all bg-white text-gray-900 placeholder-gray-400"
                      placeholder="••••••••"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end">
                  <button
                    type="button"
                    onClick={() => setIsResettingPassword(true)}
                    className="text-sm text-blue-600 hover:text-blue-700 font-medium"
                  >
                    Esqueceu a senha?
                  </button>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg"
                >
                  Entrar
                </Button>

                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="text-blue-600 flex-shrink-0 mt-0.5" size={20} />
                    <div className="text-sm text-gray-700">
                      <p className="font-medium mb-1">Credenciais de Teste:</p>
                      <p>Email: admin@diogotech.com</p>
                      <p>Senha: admin123</p>
                    </div>
                  </div>
                </div>
              </form>
            ) : (
              <form onSubmit={handlePasswordReset} className="space-y-6">
                <div>
                  <label htmlFor="resetEmail" className="block text-sm font-medium text-gray-700 mb-2">
                    Email
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="email"
                      id="resetEmail"
                      value={resetEmail}
                      onChange={(e) => setResetEmail(e.target.value)}
                      required
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all bg-white text-gray-900 placeholder-gray-400"
                      placeholder="seu@email.com"
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg"
                >
                  Enviar Link de Recuperação
                </Button>

                <button
                  type="button"
                  onClick={() => setIsResettingPassword(false)}
                  className="w-full text-center text-sm text-gray-600 hover:text-gray-900"
                >
                  Voltar ao Login
                </button>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default LoginPage;