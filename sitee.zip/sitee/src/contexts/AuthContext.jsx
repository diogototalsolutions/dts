import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const storedAuth = localStorage.getItem('dts_auth');
    if (storedAuth) {
      const authData = JSON.parse(storedAuth);
      setIsAuthenticated(true);
      setUser(authData.user);
    }
  }, []);

  const login = (email, password) => {
    // Simple authentication - in production, use real backend
    if (email === 'admin@diogotech.com' && password === 'admin123') {
      const userData = { email, name: 'Admin' };
      setIsAuthenticated(true);
      setUser(userData);
      localStorage.setItem('dts_auth', JSON.stringify({ user: userData }));
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUser(null);
    localStorage.removeItem('dts_auth');
  };

  const resetPassword = (email) => {
    // Simulate password reset
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(true);
      }, 1000);
    });
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, login, logout, resetPassword }}>
      {children}
    </AuthContext.Provider>
  );
};