import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { 
  Plus, Edit, Trash2, Save, X, Mail, Search, 
  Phone, MapPin, FileText, Hash, User 
} from 'lucide-react';

const AdminDashboard = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('clients');

  // --- Clients Management State ---
  const [clients, setClients] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState(null);
  
  const initialClientState = {
    nome: '',
    nif: '',
    morada: '',
    contacto: '',
    email: '',
    servico: ''
  };
  const [newClient, setNewClient] = useState(initialClientState);

  // --- Company Info State ---
  const [companyInfo, setCompanyInfo] = useState({
    mission: '',
    vision: '',
    values: '',
    team: []
  });

  // --- Messages State ---
  const [messages, setMessages] = useState([]);

  // --- Load Data ---
  useEffect(() => {
    // Load data from localStorage
    const savedClients = localStorage.getItem('dts_clients');
    const savedCompanyInfo = localStorage.getItem('dts_company_info');
    const savedMessages = localStorage.getItem('dts_messages');

    if (savedClients) setClients(JSON.parse(savedClients));
    if (savedCompanyInfo) setCompanyInfo(JSON.parse(savedCompanyInfo));
    if (savedMessages) setMessages(JSON.parse(savedMessages));
  }, []);

  // --- Clients Handlers ---
  const validateClientForm = (client) => {
    if (!client.nome || !client.nif || !client.morada || !client.contacto || !client.email || !client.servico) {
      toast({
        title: "Campos Obrigatórios",
        description: "Por favor, preencha todos os campos do formulário.",
        variant: "destructive",
      });
      return false;
    }
    
    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(client.email)) {
      toast({
        title: "Email Inválido",
        description: "Por favor, insira um endereço de email válido.",
        variant: "destructive",
      });
      return false;
    }

    // Simple phone validation (at least 9 digits)
    const phoneRegex = /^\d{9,}$/;
    if (!phoneRegex.test(client.contacto.replace(/\D/g, ''))) {
      toast({
        title: "Telefone Inválido",
        description: "O telefone deve conter pelo menos 9 dígitos.",
        variant: "destructive",
      });
      return false;
    }

    return true;
  };

  const handleAddClient = (e) => {
    e.preventDefault();
    
    if (!validateClientForm(newClient)) return;

    const client = {
      id: Date.now(),
      ...newClient,
      createdAt: new Date().toLocaleDateString()
    };

    const updatedClients = [...clients, client];
    setClients(updatedClients);
    localStorage.setItem('dts_clients', JSON.stringify(updatedClients));

    setNewClient(initialClientState);

    toast({
      title: "Cliente Adicionado! ✓",
      description: `${client.nome} foi adicionado à lista de clientes.`,
    });
  };

  const handleDeleteClient = (id) => {
    if (window.confirm('Tem certeza que deseja remover este cliente? Esta ação não pode ser desfeita.')) {
      const updatedClients = clients.filter(c => c.id !== id);
      setClients(updatedClients);
      localStorage.setItem('dts_clients', JSON.stringify(updatedClients));

      toast({
        title: "Cliente Removido",
        description: "O cliente foi removido com sucesso.",
      });
    }
  };

  const startEditClient = (client) => {
    setEditingClient({ ...client });
    setIsEditModalOpen(true);
  };

  const handleUpdateClient = (e) => {
    e.preventDefault();
    
    if (!validateClientForm(editingClient)) return;

    const updatedClients = clients.map(c => 
      c.id === editingClient.id ? editingClient : c
    );
    
    setClients(updatedClients);
    localStorage.setItem('dts_clients', JSON.stringify(updatedClients));
    
    setIsEditModalOpen(false);
    setEditingClient(null);

    toast({
      title: "Cliente Atualizado! ✓",
      description: "As informações do cliente foram salvas.",
    });
  };

  const filteredClients = clients.filter(client => 
    client.nome.toLowerCase().includes(searchQuery.toLowerCase()) ||
    client.nif.includes(searchQuery) ||
    client.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // --- Company Info Handlers ---
  const handleSaveCompanyInfo = () => {
    localStorage.setItem('dts_company_info', JSON.stringify(companyInfo));
    toast({
      title: "Informações Salvas! ✓",
      description: "As informações da empresa foram atualizadas.",
    });
  };

  // --- Messages Handlers ---
  const handleDeleteMessage = (id) => {
    const updatedMessages = messages.filter(m => m.id !== id);
    setMessages(updatedMessages);
    localStorage.setItem('dts_messages', JSON.stringify(updatedMessages));
    toast({ title: "Mensagem Removida! ✓" });
  };

  return (
    <>
      <Helmet>
        <title>Dashboard Admin - Diogo Tech Solutions</title>
        <meta name="description" content="Painel administrativo da Diogo Tech Solutions" />
      </Helmet>

      <div className="min-h-screen bg-gray-50 pt-20 pb-12">
        <div className="container mx-auto px-4 md:px-6 py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900">
                Painel Administrativo
              </h1>
              <div className="text-sm text-gray-500 bg-white px-4 py-2 rounded-lg shadow-sm border border-gray-200">
                Olá, Admin
              </div>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-8 bg-white p-1 shadow-sm border border-gray-200 rounded-lg">
                <TabsTrigger value="clients" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">Gerenciar Clientes</TabsTrigger>
                <TabsTrigger value="company" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">Informações da Empresa</TabsTrigger>
                <TabsTrigger value="messages" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">Mensagens</TabsTrigger>
              </TabsList>

              {/* --- Clients Tab --- */}
              <TabsContent value="clients" className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Add Client Form */}
                  <div className="lg:col-span-1">
                    <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden sticky top-24">
                      <div className="bg-blue-600 px-6 py-4">
                        <h2 className="text-xl font-bold text-white flex items-center gap-2">
                          <Plus size={20} />
                          Novo Cliente
                        </h2>
                      </div>
                      <div className="p-6">
                        <form onSubmit={handleAddClient} className="space-y-4">
                          <div>
                            <label className="text-sm font-medium text-gray-700 mb-1 block">Nome Completo</label>
                            <div className="relative">
                              <User size={16} className="absolute left-3 top-3 text-gray-400" />
                              <input
                                type="text"
                                value={newClient.nome}
                                onChange={(e) => setNewClient({ ...newClient, nome: e.target.value })}
                                className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                placeholder="Nome do Cliente"
                              />
                            </div>
                          </div>
                          
                          <div>
                            <label className="text-sm font-medium text-gray-700 mb-1 block">NIF</label>
                            <div className="relative">
                              <Hash size={16} className="absolute left-3 top-3 text-gray-400" />
                              <input
                                type="text"
                                value={newClient.nif}
                                onChange={(e) => setNewClient({ ...newClient, nif: e.target.value })}
                                className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                placeholder="000 000 000"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="text-sm font-medium text-gray-700 mb-1 block">Email</label>
                            <div className="relative">
                              <Mail size={16} className="absolute left-3 top-3 text-gray-400" />
                              <input
                                type="email"
                                value={newClient.email}
                                onChange={(e) => setNewClient({ ...newClient, email: e.target.value })}
                                className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                placeholder="cliente@email.com"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="text-sm font-medium text-gray-700 mb-1 block">Contacto</label>
                            <div className="relative">
                              <Phone size={16} className="absolute left-3 top-3 text-gray-400" />
                              <input
                                type="tel"
                                value={newClient.contacto}
                                onChange={(e) => setNewClient({ ...newClient, contacto: e.target.value })}
                                className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                placeholder="(00) 00000-0000"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="text-sm font-medium text-gray-700 mb-1 block">Morada</label>
                            <div className="relative">
                              <MapPin size={16} className="absolute left-3 top-3 text-gray-400" />
                              <input
                                type="text"
                                value={newClient.morada}
                                onChange={(e) => setNewClient({ ...newClient, morada: e.target.value })}
                                className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                placeholder="Endereço completo"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="text-sm font-medium text-gray-700 mb-1 block">Serviço</label>
                            <div className="relative">
                              <FileText size={16} className="absolute left-3 top-3 text-gray-400" />
                              <input
                                type="text"
                                value={newClient.servico}
                                onChange={(e) => setNewClient({ ...newClient, servico: e.target.value })}
                                className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                placeholder="Ex: Website Institucional"
                              />
                            </div>
                          </div>

                          <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 mt-2">
                            <Plus className="mr-2" size={18} />
                            Adicionar Cliente
                          </Button>
                        </form>
                      </div>
                    </div>
                  </div>

                  {/* Clients List */}
                  <div className="lg:col-span-2 space-y-6">
                    {/* Search Bar */}
                    <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
                      <div className="relative">
                        <Search className="absolute left-3 top-3 text-gray-400" size={20} />
                        <input
                          type="text"
                          placeholder="Buscar por nome, NIF ou email..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                        />
                      </div>
                    </div>

                    {/* Table */}
                    <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
                      <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                        <h2 className="text-xl font-bold text-gray-900">
                          Lista de Clientes
                        </h2>
                        <span className="text-sm text-gray-500 bg-white px-3 py-1 rounded-full border border-gray-200">
                          {filteredClients.length} Registros
                        </span>
                      </div>
                      
                      <div className="overflow-x-auto">
                        {filteredClients.length === 0 ? (
                          <div className="p-12 text-center text-gray-500">
                            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                              <User size={32} className="text-gray-400" />
                            </div>
                            <h3 className="text-lg font-medium text-gray-900">Nenhum cliente encontrado</h3>
                            <p className="mt-1">Tente ajustar sua busca ou adicione um novo cliente.</p>
                          </div>
                        ) : (
                          <table className="w-full text-left border-collapse">
                            <thead>
                              <tr className="bg-gray-50 text-gray-600 text-sm uppercase tracking-wider">
                                <th className="px-6 py-4 font-semibold">Cliente / NIF</th>
                                <th className="px-6 py-4 font-semibold">Contato</th>
                                <th className="px-6 py-4 font-semibold">Serviço</th>
                                <th className="px-6 py-4 font-semibold text-right">Ações</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                              {filteredClients.map((client) => (
                                <tr key={client.id} className="hover:bg-blue-50/50 transition-colors group">
                                  <td className="px-6 py-4">
                                    <div className="flex flex-col">
                                      <span className="font-semibold text-gray-900">{client.nome}</span>
                                      <span className="text-sm text-gray-500 font-mono">{client.nif}</span>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4">
                                    <div className="flex flex-col text-sm">
                                      <span className="flex items-center gap-1 text-gray-700">
                                        <Mail size={12} className="text-blue-500" /> {client.email}
                                      </span>
                                      <span className="flex items-center gap-1 text-gray-700 mt-1">
                                        <Phone size={12} className="text-green-500" /> {client.contacto}
                                      </span>
                                    </div>
                                  </td>
                                  <td className="px-6 py-4">
                                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                      {client.servico}
                                    </span>
                                  </td>
                                  <td className="px-6 py-4 text-right">
                                    <div className="flex justify-end gap-2">
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => startEditClient(client)}
                                        className="h-8 w-8 p-0 text-blue-600 hover:text-blue-700 hover:bg-blue-50 border-blue-200"
                                      >
                                        <Edit size={14} />
                                      </Button>
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => handleDeleteClient(client.id)}
                                        className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                                      >
                                        <Trash2 size={14} />
                                      </Button>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* --- Company Info Tab --- */}
              <TabsContent value="company">
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 md:p-8">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-gray-900">Editar Informações da Empresa</h2>
                    <Save className="text-gray-400" />
                  </div>
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Missão</label>
                      <textarea
                        value={companyInfo.mission}
                        onChange={(e) => setCompanyInfo({ ...companyInfo, mission: e.target.value })}
                        rows="3"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 bg-white text-gray-900 placeholder-gray-400 transition-shadow"
                        placeholder="Descreva a missão da empresa..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Visão</label>
                      <textarea
                        value={companyInfo.vision}
                        onChange={(e) => setCompanyInfo({ ...companyInfo, vision: e.target.value })}
                        rows="3"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 bg-white text-gray-900 placeholder-gray-400 transition-shadow"
                        placeholder="Descreva a visão da empresa..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Valores</label>
                      <textarea
                        value={companyInfo.values}
                        onChange={(e) => setCompanyInfo({ ...companyInfo, values: e.target.value })}
                        rows="3"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 bg-white text-gray-900 placeholder-gray-400 transition-shadow"
                        placeholder="Descreva os valores da empresa..."
                      />
                    </div>
                    <div className="pt-4 border-t border-gray-100">
                      <Button onClick={handleSaveCompanyInfo} className="bg-blue-600 hover:bg-blue-700 text-white w-full md:w-auto">
                        <Save className="mr-2" size={20} />
                        Salvar Alterações
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* --- Messages Tab --- */}
              <TabsContent value="messages">
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 md:p-8">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-gray-900">Mensagens Recebidas</h2>
                    <span className="text-sm font-medium bg-blue-100 text-blue-800 px-3 py-1 rounded-full">
                      {messages.length} Nova(s)
                    </span>
                  </div>
                  <div className="space-y-4">
                    {messages.length === 0 ? (
                      <div className="text-center py-12 bg-gray-50 rounded-lg border border-dashed border-gray-300">
                        <Mail className="mx-auto h-12 w-12 text-gray-400 mb-3" />
                        <p className="text-gray-500 font-medium">Nenhuma mensagem recebida ainda.</p>
                      </div>
                    ) : (
                      messages.map((message) => (
                        <motion.div 
                          key={message.id}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="p-5 border border-gray-200 rounded-xl hover:shadow-md transition-all bg-white group"
                        >
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <h3 className="font-bold text-gray-900 text-lg">{message.nome}</h3>
                              <p className="text-sm text-gray-500 flex items-center gap-2 mt-1">
                                <Mail size={14} className="text-blue-500" />
                                <a href={`mailto:${message.email}`} className="hover:text-blue-600 underline-offset-4 hover:underline">
                                  {message.email}
                                </a>
                              </p>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteMessage(message.id)}
                              className="text-gray-400 hover:text-red-600 hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <Trash2 size={18} />
                            </Button>
                          </div>
                          <div className="bg-gray-50 p-4 rounded-lg text-gray-700 text-sm leading-relaxed border border-gray-100">
                            {message.mensagem}
                          </div>
                          <p className="text-xs text-gray-400 mt-3 flex justify-end">
                            Recebido em: {message.date || new Date().toLocaleDateString()}
                          </p>
                        </motion.div>
                      ))
                    )}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </motion.div>
        </div>
      </div>

      {/* Edit Client Modal */}
      <AnimatePresence>
        {isEditModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden"
            >
              <div className="bg-blue-600 px-6 py-4 flex justify-between items-center">
                <h3 className="text-xl font-bold text-white flex items-center gap-2">
                  <Edit size={20} />
                  Editar Cliente
                </h3>
                <button 
                  onClick={() => setIsEditModalOpen(false)}
                  className="text-blue-100 hover:text-white hover:bg-blue-700 p-1 rounded-full transition-colors"
                >
                  <X size={24} />
                </button>
              </div>
              
              <div className="p-6">
                <form onSubmit={handleUpdateClient} className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1 block">Nome Completo</label>
                    <input
                      type="text"
                      value={editingClient?.nome || ''}
                      onChange={(e) => setEditingClient({ ...editingClient, nome: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-1 block">NIF</label>
                      <input
                        type="text"
                        value={editingClient?.nif || ''}
                        onChange={(e) => setEditingClient({ ...editingClient, nif: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-1 block">Contacto</label>
                      <input
                        type="tel"
                        value={editingClient?.contacto || ''}
                        onChange={(e) => setEditingClient({ ...editingClient, contacto: e.target.value })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1 block">Email</label>
                    <input
                      type="email"
                      value={editingClient?.email || ''}
                      onChange={(e) => setEditingClient({ ...editingClient, email: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1 block">Morada</label>
                    <input
                      type="text"
                      value={editingClient?.morada || ''}
                      onChange={(e) => setEditingClient({ ...editingClient, morada: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1 block">Serviço</label>
                    <input
                      type="text"
                      value={editingClient?.servico || ''}
                      onChange={(e) => setEditingClient({ ...editingClient, servico: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>

                  <div className="pt-4 flex gap-3">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setIsEditModalOpen(false)}
                      className="flex-1"
                    >
                      Cancelar
                    </Button>
                    <Button 
                      type="submit" 
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                    >
                      Salvar Alterações
                    </Button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};

export default AdminDashboard;