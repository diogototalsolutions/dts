import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Linkedin, MessageCircle, Mail } from 'lucide-react';
const Footer = () => {
  const quickLinks = [{
    name: 'Home',
    path: '/'
  }, {
    name: 'Sobre Nós',
    path: '/sobre'
  }, {
    name: 'Portfólio',
    path: '/portfolio'
  }, {
    name: 'Contato',
    path: '/contato'
  }];
  const socialLinks = [{
    icon: Facebook,
    href: 'https://www.facebook.com/DiogoTechSolutions?mibextid=wwXIfr&rdid=GQUBAGw8Z9jJJC2Y&share_url=https%3A%2F%2Fwww.facebook.com%2Fshare%2F1Amdo7RrRP%2F%3Fmibextid%3DwwXIfr#',
    label: 'Facebook'
  }, {
    icon: Instagram,
    href: 'https://www.instagram.com/diogototalsolutions?igsh=MmlvY2d6bnk5Njdx&utm_source=qr',
    label: 'Instagram'
  }, {
    icon: Linkedin,
    href: 'https://www.linkedin.com/in/diogo-bizarro-3621a322a/?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app',
    label: 'LinkedIn'
  }, {
    icon: MessageCircle,
    href: 'https://wa.me/932344080',
    label: 'WhatsApp'
  }];
  return <footer className="bg-gradient-to-b from-gray-900 to-black text-white">
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Logo e Descrição */}
          <div className="space-y-4">
            <img src="https://horizons-cdn.hostinger.com/c7ead2cc-c9d2-4819-948e-421c71680a94/a697d1962d9c248c045374b150919108.jpg" alt="Diogo Tech Solutions" className="h-12 w-auto object-contain" />
            <p className="text-gray-400 text-sm leading-relaxed">
              Transformando ideias em soluções tecnológicas inovadoras.
            </p>
          </div>

          {/* Links Rápidos */}
          <div>
            <h3 className="font-bold text-lg mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              {quickLinks.map(link => <li key={link.path}>
                  <Link to={link.path} className="text-gray-400 hover:text-blue-400 transition-colors duration-300 text-sm">
                    {link.name}
                  </Link>
                </li>)}
            </ul>
          </div>

          {/* Contato e Redes Sociais */}
          <div>
            <h3 className="font-bold text-lg mb-4">Contatos</h3>
            <div className="space-y-3">
              <a href="mailto:diogotechsolutions@gmail.com" className="flex items-center gap-2 text-gray-400 hover:text-blue-400 transition-colors duration-300 text-sm">
                <Mail size={16} />
                <span>diogotechsolutions@gmail.com</span>
              </a>
              
              <div className="flex gap-4 mt-4">
                {socialLinks.map(social => <a key={social.label} href={social.href} target="_blank" rel="noopener noreferrer" className="p-2 bg-gray-800 rounded-lg hover:bg-blue-600 transition-all duration-300 hover:scale-110" aria-label={social.label}>
                    <social.icon size={20} />
                  </a>)}
              </div>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} Diogo Tech Solutions. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>;
};
export default Footer;