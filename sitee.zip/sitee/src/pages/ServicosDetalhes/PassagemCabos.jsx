import React from 'react';
import ServiceDetail from '@/components/ServiceDetail';

const PassagemCabos = () => {
  return (
    <ServiceDetail
      title="Passagem de Cabos"
      description="Soluções profissionais para infraestrutura de rede corporativa e residencial. Garantimos organização, performance e durabilidade para sua conexão."
      features={[
        "Instalação e organização de cabos de rede (Cat5e, Cat6, Cat6a, Cat7)",
        "Passagem e fusão de fibra ótica para alta velocidade",
        "Organização de Racks e Datacenters",
        "Certificação de pontos de rede com relatórios técnicos",
        "Instalação de infraestrutura para TV e sistemas de áudio",
        "Remoção de cabos antigos e reestruturação completa do cabeamento"
      ]}
      images={[
        "https://images.unsplash.com/photo-1594915440248-1e419eba6611",
        "https://images.unsplash.com/photo-1702822903693-0a18874d881e",
        "https://images.unsplash.com/photo-1606908487894-c7e94a213233"
      ]}
    />
  );
};

export default PassagemCabos;