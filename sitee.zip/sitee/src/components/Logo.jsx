import React from 'react';
import { motion } from 'framer-motion';

const Logo = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex items-center space-x-1"
    >
      <span className="text-2xl md:text-3xl font-extrabold text-[#0066CC] leading-none">
        Diogo
      </span>
      <span className="text-2xl md:text-3xl font-extrabold text-[#666666] leading-none">
        Solutions
      </span>
    </motion.div>
  );
};

export default Logo;