import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';
import { ArrowRight, Cable, Wifi, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
const HomePage = () => {
  const location = useLocation();
  useEffect(() => {
    if (location.hash === '#servicos') {
      const element = document.getElementById('servicos');
      if (element) {
        element.scrollIntoView({
          behavior: 'smooth'
        });
      }
    }
  }, [location]);
    return <>
      <Helmet>
        <title>Diogo Tech Solutions - Soluções Tecnológicas Inovadoras</title>
        <meta name="description" content="Transformamos suas ideias em realidade com soluções tecnológicas personalizadas. Web design, desenvolvimento mobile e branding." />
      </Helmet>

      {/* Hero Banner */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center" style={{
        backgroundImage: 'url(https://images.unsplash.com/photo-1684563983781-ce52a026f139)'
      }}>
          <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 via-blue-800/80 to-transparent"></div>
        </div>
        
        <div className="relative z-10 container mx-auto px-6 text-white">
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8
        }} className="max-w-3xl">
            <motion.h1 initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.8,
            delay: 0.2
          }} className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Diogo <span className="text-blue-400">Total Solutions</span>
            </motion.h1>
            <motion.p initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.8,
            delay: 0.4
          }} className="text-xl md:text-2xl mb-8 text-gray-200">Soluções tecnológicas para a otimização da tecnologia.</motion.p>
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.8,
            delay: 0.6
          }} className="flex flex-wrap gap-4">
              <Link to="/portfolio">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white text-lg px-8 py-6">
                  Ver Portfólio
                  <ArrowRight className="ml-2" />
                </Button>
              </Link>
              <Link to="/contato">
                <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white/10 text-lg px-8 py-6">
                  Fale Conosco
                </Button>
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Services Section (Formerly Quick Actions) */}
      <section id="servicos" className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }} className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Nossos Serviços
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Soluções completas para sua infraestrutura tecnológica
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Passagem de Cabos */}
            <motion.div initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6
          }} className="group relative">
              <Link to="/servicos/passagem-cabos" className="block h-full">
                <div className="h-full text-center p-8 rounded-xl bg-gradient-to-br from-blue-50 to-white shadow-lg group-hover:shadow-2xl transition-all duration-300 transform group-hover:-translate-y-2 border border-blue-100">
                  <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-md group-hover:scale-110 transition-transform duration-300">
                    <Cable className="text-white" size={36} />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">Passagem de Cabos</h3>
                  <p className="text-gray-700 font-medium mb-2">Sistema web corporativo para Cabos de rede, TV e Fibra Ótica</p>
                  <p className="text-gray-500 text-sm mb-6">Montagem e otimização de redes</p>
                  <Button variant="outline" className="border-blue-600 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all">
                    Saiba Mais
                  </Button>
                </div>
              </Link>
            </motion.div>

            {/* Otimização WiFi */}
            <motion.div initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6,
            delay: 0.1
          }} className="group relative">
              <Link to="/servicos/otimizacao-wifi" className="block h-full">
                <div className="h-full text-center p-8 rounded-xl bg-gradient-to-br from-blue-50 to-white shadow-lg group-hover:shadow-2xl transition-all duration-300 transform group-hover:-translate-y-2 border border-blue-100">
                  <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-md group-hover:scale-110 transition-transform duration-300">
                    <Wifi className="text-white" size={36} />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">Otimização WiFi</h3>
                  <p className="text-gray-700 font-medium mb-2">Tp-Link, rede Mesh, Switch</p>
                  <p className="text-gray-500 text-sm mb-6">Redes otimizadas, sinal wifi excelente</p>
                  <Button variant="outline" className="border-blue-600 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all">
                    Saiba Mais
                  </Button>
                </div>
              </Link>
            </motion.div>

            {/* Instalação de Câmaras */}
            <motion.div initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6,
            delay: 0.2
          }} className="group relative">
              <Link to="/servicos/instalacao-cameras" className="block h-full">
                <div className="h-full text-center p-8 rounded-xl bg-gradient-to-br from-blue-50 to-white shadow-lg group-hover:shadow-2xl transition-all duration-300 transform group-hover:-translate-y-2 border border-blue-100">
                  <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-md group-hover:scale-110 transition-transform duration-300">
                    <Camera className="text-white" size={36} />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">Instalação de Câmaras</h3>
                  <p className="text-gray-700 font-medium mb-2">Venda, montagem, instalação</p>
                  <p className="text-gray-500 text-sm mb-6">HikVision, Dahua, Tapo, TPlink</p>
                  <Button variant="outline" className="border-blue-600 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all">
                    Saiba Mais
                  </Button>
                </div>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Portfolio Highlights */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }} className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4"></h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto"></p>
          </motion.div>

          
          <motion.div initial={{
          opacity: 0
        }} whileInView={{
          opacity: 1
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6,
          delay: 0.4
        }} className="text-center mt-12">
            <Link to="/portfolio">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
                Ver Todos os Projetos
                <ArrowRight className="ml-2" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="container mx-auto px-6 text-center">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.6
        }}>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Pronto para Transformar Seu Negócio?
            </h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto text-blue-100">
              Entre em contato conosco e descubra como podemos ajudar a levar sua empresa ao próximo nível
            </p>
            <Link to="/contato">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100 text-lg px-8 py-6">
                Começar Agora
                <ArrowRight className="ml-2" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </>;
};
export default HomePage;