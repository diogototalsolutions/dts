import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Target, Eye, Award } from 'lucide-react';

const SobreNos = () => {
  const teamMembers = [
    {
      id: 1,
      name: 'Diogo Silva',
      role: 'CEO & Desenvolvedor Full Stack',
      image: 'https://images.unsplash.com/photo-1627599936744-51d288f89af4'
    },
    {
      id: 2,
      name: 'Maria Santos',
      role: 'Designer UX/UI',
      image: 'https://images.unsplash.com/photo-1514996937319-344454492b37'
    }
  ];

  const values = [
    {
      icon: Target,
      title: 'Missão',
      description: 'Fornecer soluções tecnológicas inovadoras e personalizadas que impulsionam o crescimento e a transformação digital dos nossos clientes.'
    },
    {
      icon: Eye,
      title: 'Visão',
      description: 'Ser reconhecida como referência em desenvolvimento de soluções tecnológicas, destacando-se pela excelência, inovação e compromisso com resultados.'
    },
    {
      icon: Award,
      title: 'Valores',
      description: 'Inovação contínua, compromisso com a qualidade, transparência nas relações, respeito ao cliente e busca pela excelência em cada projeto.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Sobre Nós - Diogo Tech Solutions</title>
        <meta name="description" content="Conheça a Diogo Tech Solutions, nossa história, missão, visão, valores e a equipe que transforma ideias em soluções tecnológicas." />
      </Helmet>

      <div className="pt-20">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
          <div className="container mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-3xl mx-auto text-center"
            >
              <h1 className="text-5xl md:text-6xl font-bold mb-6">
                Sobre Nós
              </h1>
              <p className="text-xl text-blue-100">
                Conheça a história e os valores que nos guiam
              </p>
            </motion.div>
          </div>
        </section>

        {/* Company Description */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto"
            >
              <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">
                Nossa História
              </h2>
              <div className="space-y-6 text-lg text-gray-700 leading-relaxed">
                <p>
                  A <strong>Diogo Tech Solutions</strong> nasceu da paixão por tecnologia e do desejo de ajudar empresas a alcançarem seu máximo potencial através de soluções digitais inovadoras.
                </p>
                <p>
                  Com anos de experiência no mercado, nossa equipe se dedica a entender as necessidades específicas de cada cliente, desenvolvendo projetos personalizados que vão desde sites institucionais até sistemas complexos e aplicativos mobile.
                </p>
                <p>
                  Acreditamos que a tecnologia deve ser acessível e eficiente, por isso trabalhamos com as melhores práticas do mercado, sempre mantendo o foco na experiência do usuário e nos resultados do negócio.
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Mission, Vision, Values */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Nossos Pilares
              </h2>
              <p className="text-xl text-gray-600">
                Os princípios que orientam nosso trabalho
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {values.map((value, index) => (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-white p-8 rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300"
                >
                  <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-6">
                    <value.icon className="text-white" size={32} />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">
                    {value.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {value.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Team Members */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Nossa Equipe
              </h2>
              <p className="text-xl text-gray-600">
                Profissionais dedicados ao seu sucesso
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-4xl mx-auto">
              {teamMembers.map((member, index) => (
                <motion.div
                  key={member.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="group text-center"
                >
                  <div className="relative mb-6 overflow-hidden rounded-xl">
                    <img 
                      src={member.image} 
                      alt={member.name}
                      className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-blue-900/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    {member.name}
                  </h3>
                  <p className="text-blue-600 font-medium">
                    {member.role}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Google Maps */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Nossa Localização
              </h2>
              <p className="text-xl text-gray-600">
                Venha nos visitar
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="rounded-xl overflow-hidden shadow-2xl"
            >
              <iframe
                src="https://www.openstreetmap.org/export/embed.html?bbox=-46.633309%2C-23.550520%2C-46.631309%2C-23.548520&layer=mapnik&marker=-23.549520%2C-46.632309"
                width="100%"
                height="450"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Localização Diogo Tech Solutions"
              ></iframe>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default SobreNos;