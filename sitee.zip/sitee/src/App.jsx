import React from 'react';
import { Route, Routes, BrowserRouter as Router, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import ScrollToTop from '@/components/ScrollToTop';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HomePage from '@/pages/HomePage';
import SobreNos from '@/pages/SobreNos';
import Portfolio from '@/pages/Portfolio';
import Contato from '@/pages/Contato';
import LoginPage from '@/pages/LoginPage';
import AdminDashboard from '@/pages/AdminDashboard';
import PassagemCabos from '@/pages/ServicosDetalhes/PassagemCabos';
import OtimizacaoWiFi from '@/pages/ServicosDetalhes/OtimizacaoWiFi';
import InstalacaoCameras from '@/pages/ServicosDetalhes/InstalacaoCameras';

const ProtectedRoute = ({ children }) => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? children : <Navigate to="/login" replace />;
};

function AppContent() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/sobre" element={<SobreNos />} />
          <Route path="/portfolio" element={<Portfolio />} />
          <Route path="/contato" element={<Contato />} />
          
          {/* Services Routes */}
          <Route path="/servicos/passagem-cabos" element={<PassagemCabos />} />
          <Route path="/servicos/otimizacao-wifi" element={<OtimizacaoWiFi />} />
          <Route path="/servicos/instalacao-cameras" element={<InstalacaoCameras />} />

          <Route path="/login" element={<LoginPage />} />
          <Route 
            path="/admin/dashboard" 
            element={
              <ProtectedRoute>
                <AdminDashboard />
              </ProtectedRoute>
            } 
          />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <Router>
      <AuthProvider>
        <ScrollToTop />
        <AppContent />
      </AuthProvider>
    </Router>
  );
}

export default App;