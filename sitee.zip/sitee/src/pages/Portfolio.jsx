import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

const Portfolio = () => {
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [selectedImage, setSelectedImage] = useState(null);

  const categories = ['Todos', 'Web Design', 'Mobile Apps', 'Branding'];

  const projects = [
    {
      id: 1,
      title: 'Sistema Web Corporativo',
      category: 'Web Design',
      image: 'https://images.unsplash.com/photo-1687006067259-6de13ca3875e',
      description: 'Plataforma completa de gestão empresarial com dashboard interativo'
    },
    {
      id: 2,
      title: 'App de Delivery',
      category: 'Mobile Apps',
      image: 'https://images.unsplash.com/photo-1524221629551-6dd14def5ffd',
      description: 'Aplicativo mobile para delivery e logística em tempo real'
    },
    {
      id: 3,
      title: 'Identidade Visual Tech',
      category: 'Branding',
      image: 'https://images.unsplash.com/photo-1678690832311-bb6e361989ca',
      description: 'Branding completo para startup de tecnologia'
    },
    {
      id: 4,
      title: 'E-commerce Moderno',
      category: 'Web Design',
      image: 'https://images.unsplash.com/photo-1687006067259-6de13ca3875e',
      description: 'Loja virtual responsiva com integração de pagamentos'
    },
    {
      id: 5,
      title: 'App Fitness',
      category: 'Mobile Apps',
      image: 'https://images.unsplash.com/photo-1524221629551-6dd14def5ffd',
      description: 'Aplicativo de treinos personalizados com IA'
    },
    {
      id: 6,
      title: 'Rebranding Corporativo',
      category: 'Branding',
      image: 'https://images.unsplash.com/photo-1678690832311-bb6e361989ca',
      description: 'Renovação completa da identidade visual de empresa consolidada'
    }
  ];

  const filteredProjects = selectedCategory === 'Todos' 
    ? projects 
    : projects.filter(p => p.category === selectedCategory);

  return (
    <>
      <Helmet>
        <title>Portfólio - Diogo Tech Solutions</title>
        <meta name="description" content="Confira nosso portfólio de projetos em web design, desenvolvimento mobile e branding. Soluções tecnológicas que transformam negócios." />
      </Helmet>

      <div className="pt-20">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
          <div className="container mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-3xl mx-auto text-center"
            >
              <h1 className="text-5xl md:text-6xl font-bold mb-6">
                Nosso Portfólio
              </h1>
              <p className="text-xl text-blue-100">
                Projetos que transformam ideias em realidade digital
              </p>
            </motion.div>
          </div>
        </section>

        {/* Category Filter */}
        <section className="py-12 bg-white sticky top-20 z-40 shadow-sm">
          <div className="container mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="flex flex-wrap justify-center gap-4"
            >
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-6 py-3 rounded-lg font-medium transition-all duration-300 ${
                    selectedCategory === category
                      ? 'bg-blue-600 text-white shadow-lg scale-105'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </motion.div>
          </div>
        </section>

        {/* Projects Grid */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedCategory}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
              >
                {filteredProjects.map((project, index) => (
                  <motion.div
                    key={project.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="group bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer"
                    onClick={() => setSelectedImage(project)}
                  >
                    <div className="relative h-64 overflow-hidden">
                      <img 
                        src={project.image} 
                        alt={project.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                        <div className="text-white">
                          <p className="text-sm font-semibold uppercase tracking-wide mb-2">
                            {project.category}
                          </p>
                          <h3 className="text-xl font-bold">
                            {project.title}
                          </h3>
                        </div>
                      </div>
                    </div>
                    <div className="p-6">
                      <span className="text-sm font-semibold text-blue-600 uppercase tracking-wide">
                        {project.category}
                      </span>
                      <h3 className="text-xl font-bold text-gray-900 mt-2 mb-2">
                        {project.title}
                      </h3>
                      <p className="text-gray-600">
                        {project.description}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            </AnimatePresence>
          </div>
        </section>

        {/* Lightbox Modal */}
        <AnimatePresence>
          {selectedImage && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
              onClick={() => setSelectedImage(null)}
            >
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="relative max-w-5xl w-full"
                onClick={(e) => e.stopPropagation()}
              >
                <button
                  onClick={() => setSelectedImage(null)}
                  className="absolute -top-12 right-0 text-white hover:text-blue-400 transition-colors"
                >
                  <X size={32} />
                </button>
                <img 
                  src={selectedImage.image} 
                  alt={selectedImage.title}
                  className="w-full h-auto rounded-lg shadow-2xl"
                />
                <div className="mt-6 text-white text-center">
                  <span className="text-sm font-semibold text-blue-400 uppercase tracking-wide">
                    {selectedImage.category}
                  </span>
                  <h3 className="text-2xl font-bold mt-2 mb-2">
                    {selectedImage.title}
                  </h3>
                  <p className="text-gray-300">
                    {selectedImage.description}
                  </p>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
};

export default Portfolio;