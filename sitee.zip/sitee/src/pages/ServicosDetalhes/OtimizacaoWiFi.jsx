import React from 'react';
import ServiceDetail from '@/components/ServiceDetail';

const OtimizacaoWiFi = () => {
  return (
    <ServiceDetail
      title="Otimização WiFi"
      description="Acabe com as zonas de sombra e lentidão na sua internet. Projetamos e implementamos redes WiFi de alta performance para cobrir 100% do seu ambiente."
      features={[
        "Análise de espectro e mapeamento de sinal (Heatmap)",
        "Instalação e configuração de redes Mesh para cobertura total",
        "Configuração de Access Points (APs) profissionais (Ubiquiti, TP-Link Omada)",
        "Otimização de canais para evitar interferências",
        "Configuração de redes para visitantes (Guest WiFi) com portal cativo",
        "Implementação de Switches gerenciáveis para melhor distribuição de tráfego"
      ]}
      images={[
        "https://images.unsplash.com/photo-1681383064412-171e5bee5f6e",
        "https://images.unsplash.com/photo-1606421753414-8d165c9d48e5",
        "https://images.unsplash.com/photo-1670348654379-e736327ec4c0"
      ]}
    />
  );
};

export default OtimizacaoWiFi;