import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ServiceDetail = ({ title, description, features, images }) => {
  return (
    <>
      <Helmet>
        <title>{title} - Diogo Tech Solutions</title>
        <meta name="description" content={description.substring(0, 150)} />
      </Helmet>

      <div className="pt-20 min-h-screen bg-gray-50">
        {/* Header Section */}
        <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
          <div className="container mx-auto px-6">
            <Link to="/" className="inline-flex items-center text-blue-100 hover:text-white mb-8 transition-colors">
              <ArrowLeft className="mr-2" size={20} />
              Voltar para Home
            </Link>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-6">{title}</h1>
              <p className="text-xl md:text-2xl text-blue-100 max-w-3xl leading-relaxed">
                {description}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Content Section */}
        <section className="py-16">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
              {/* Text Content */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="bg-white p-8 rounded-2xl shadow-lg"
              >
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Sobre o Serviço</h2>
                <div className="prose prose-blue max-w-none text-gray-600 leading-relaxed space-y-4">
                  {features && features.map((feature, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <div className="w-2 h-2 mt-2.5 rounded-full bg-blue-500 flex-shrink-0" />
                      <p>{feature}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-10">
                  <Link to="/contato">
                    <Button size="lg" className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg shadow-lg hover:shadow-xl transition-all">
                      <MessageSquare className="mr-2" />
                      Pedir Orçamento Gratuito
                    </Button>
                  </Link>
                </div>
              </motion.div>

              {/* Images Grid */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="grid grid-cols-1 gap-6"
              >
                {images.map((img, index) => (
                  <div 
                    key={index} 
                    className={`rounded-2xl overflow-hidden shadow-lg ${index === 0 ? 'h-64 md:h-80' : 'h-48'}`}
                  >
                    <img 
                      src={img} 
                      alt={`${title} - Imagem ${index + 1}`} 
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                ))}
              </motion.div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default ServiceDetail;