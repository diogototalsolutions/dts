import React from 'react';
import ServiceDetail from '@/components/ServiceDetail';

const InstalacaoCameras = () => {
  return (
    <ServiceDetail
      title="Instalação de Câmaras"
      description="Segurança eletrônica de ponta para proteger seu patrimônio. Oferecemos venda, instalação e manutenção de sistemas de monitoramento CCTV modernos."
      features={[
        "Projeto e instalação de sistemas de CFTV IP e Analógico",
        "Câmeras com visão noturna, áudio bidirecional e inteligência artificial",
        "Configuração de acesso remoto via celular e computador",
        "Instalação de gravadores (DVR/NVR) com armazenamento seguro",
        "Manutenção preventiva e corretiva de sistemas existentes",
        "Trabalhamos com as melhores marcas: HikVision, Dahua, Intelbras, TP-Link Tapo"
      ]}
      images={[
        "https://images.unsplash.com/photo-1698558770409-89ab5ef2e08f",
        "https://images.unsplash.com/photo-1600069620961-8bee77c2e28a",
        "https://images.unsplash.com/photo-1691214551991-ed27536cbf91"
      ]}
    />
  );
};

export default InstalacaoCameras;